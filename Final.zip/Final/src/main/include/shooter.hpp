#ifndef SHOOTERH
    #define SHOOTERH
    void shotSetup();
    void set_shooter(int input);
    void shooter_control();

#endif