#ifndef INTAKEH
    #define INTAKEH
    void set_intake(int input);
    void iSetup();
    void intake_control();
#endif